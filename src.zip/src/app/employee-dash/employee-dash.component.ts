import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-dash',
  templateUrl: './employee-dash.component.html',
  styleUrls: ['./employee-dash.component.css']
})
export class EmployeeDashComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
